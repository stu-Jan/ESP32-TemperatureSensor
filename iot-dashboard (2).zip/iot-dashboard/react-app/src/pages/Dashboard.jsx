import { useEffect, useState, useRef, useCallback } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine, Area, AreaChart,
} from 'recharts';
import {
  Thermometer, Droplets, Wifi, WifiOff, Activity,
  BarChart2, Clock, Trash2, RefreshCw, Wind,
} from 'lucide-react';

const HISTORY_LIMIT = 60;
const OFFLINE_THRESHOLD_MS = 30_000; // mark offline if no data for 30s

function formatTime(iso) {
  if (!iso) return '--';
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function formatFullTime(iso) {
  if (!iso) return '--';
  const d = new Date(iso);
  return d.toLocaleString();
}

function timeAgo(iso) {
  if (!iso) return 'never';
  const diff = Date.now() - new Date(iso).getTime();
  if (diff < 5000) return 'just now';
  if (diff < 60000) return `${Math.floor(diff / 1000)}s ago`;
  return `${Math.floor(diff / 60000)}m ago`;
}

// ── Gauge component ────────────────────────────────────────────────────────────
function Gauge({ value, min, max, unit, color, label, icon: Icon, subtitle }) {
  const pct = value !== null ? Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100)) : 0;
  const angle = (pct / 100) * 180 - 90;
  const r = 70;
  const cx = 90;
  const cy = 90;

  const toXY = (angleDeg, radius) => {
    const rad = (angleDeg * Math.PI) / 180;
    return { x: cx + radius * Math.cos(rad), y: cy + radius * Math.sin(rad) };
  };

  const arcPath = (startAngle, endAngle, radius) => {
    const s = toXY(startAngle, radius);
    const e = toXY(endAngle, radius);
    const large = endAngle - startAngle > 180 ? 1 : 0;
    return `M ${s.x} ${s.y} A ${radius} ${radius} 0 ${large} 1 ${e.x} ${e.y}`;
  };

  const needleTip = toXY(angle - 90, r - 10);

  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 180 100" className="w-full max-w-[200px]">
        {/* Track */}
        <path d={arcPath(-180, 0, r)} fill="none" stroke="#1e293b" strokeWidth="14" strokeLinecap="round" />
        {/* Fill */}
        {value !== null && (
          <path
            d={arcPath(-180, angle - 90, r)}
            fill="none"
            stroke={color}
            strokeWidth="14"
            strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 6px ${color}80)` }}
          />
        )}
        {/* Needle */}
        {value !== null && (
          <line
            x1={cx} y1={cy}
            x2={needleTip.x} y2={needleTip.y}
            stroke="#f1f5f9" strokeWidth="2" strokeLinecap="round"
          />
        )}
        <circle cx={cx} cy={cy} r="4" fill="#f1f5f9" />
        {/* Value */}
        <text x={cx} y={cy - 14} textAnchor="middle" fill={color} fontSize="22" fontWeight="700">
          {value !== null ? value.toFixed(1) : '--'}
        </text>
        <text x={cx} y={cy - 2} textAnchor="middle" fill="#94a3b8" fontSize="10">
          {unit}
        </text>
        {/* Min/Max labels */}
        <text x="12" y="96" fill="#475569" fontSize="9">{min}</text>
        <text x="162" y="96" fill="#475569" fontSize="9" textAnchor="end">{max}</text>
      </svg>
      <div className="flex items-center gap-1.5 mt-1">
        <Icon size={14} style={{ color }} />
        <span className="text-sm font-medium text-slate-300">{label}</span>
      </div>
      {subtitle && <span className="text-xs text-slate-500 mt-0.5">{subtitle}</span>}
    </div>
  );
}

// ── Stat card ─────────────────────────────────────────────────────────────────
function StatCard({ label, value, unit, color, icon: Icon }) {
  return (
    <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
      <div className="flex items-center gap-2 mb-2">
        <Icon size={14} style={{ color }} />
        <span className="text-xs text-slate-400 uppercase tracking-wider">{label}</span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="text-2xl font-bold text-slate-100">{value ?? '--'}</span>
        <span className="text-sm text-slate-400">{unit}</span>
      </div>
    </div>
  );
}

// ── Custom chart tooltip ──────────────────────────────────────────────────────
function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-slate-800 border border-slate-600 rounded-lg p-3 text-sm shadow-xl">
      <p className="text-slate-400 mb-1">{label}</p>
      {payload.map(p => (
        <p key={p.dataKey} style={{ color: p.color }}>
          {p.name}: <span className="font-semibold">{p.value?.toFixed(1)}{p.name === 'Temp' ? '°C' : '%'}</span>
        </p>
      ))}
    </div>
  );
}

// ── Main Dashboard ────────────────────────────────────────────────────────────
export default function Dashboard() {
  const [latest, setLatest] = useState(null);
  const [history, setHistory] = useState([]);
  const [stats, setStats] = useState(null);
  const [online, setOnline] = useState(false);
  const [lastSeen, setLastSeen] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState('connecting');
  const [flashUpdate, setFlashUpdate] = useState(false);
  const offlineTimerRef = useRef(null);
  const eventSourceRef = useRef(null);
  const latestTimestampRef = useRef(null);

  const markOnline = useCallback((timestamp) => {
    latestTimestampRef.current = timestamp;
    setOnline(true);
    setLastSeen(timestamp);
    setConnectionStatus('live');
    clearTimeout(offlineTimerRef.current);
    offlineTimerRef.current = setTimeout(() => {
      setOnline(false);
      setConnectionStatus('offline');
    }, OFFLINE_THRESHOLD_MS);
  }, []);

  // Flash animation on new reading
  const triggerFlash = useCallback(() => {
    setFlashUpdate(true);
    setTimeout(() => setFlashUpdate(false), 600);
  }, []);

  // Fetch initial history + stats
  const fetchInitialData = useCallback(async () => {
    try {
      const [histRes, statsRes, latestRes] = await Promise.all([
        fetch(`/api/sensor/history?limit=${HISTORY_LIMIT}`),
        fetch('/api/sensor/stats'),
        fetch('/api/sensor/latest'),
      ]);
      const hist = await histRes.json();
      const st = await statsRes.json();
      const lat = await latestRes.json();

      if (Array.isArray(hist)) {
        setHistory(hist.map(r => ({
          ...r,
          time: formatTime(r.timestamp),
        })));
      }
      setStats(st);
      if (lat) {
        setLatest(lat);
        markOnline(lat.timestamp);
      }
    } catch (e) {
      console.error('Failed to fetch initial data:', e);
    }
  }, [markOnline]);

  // SSE subscription
  useEffect(() => {
    fetchInitialData();

    const connect = () => {
      const es = new EventSource('/api/sensor/stream');
      eventSourceRef.current = es;

      es.onopen = () => setConnectionStatus('live');
      es.onerror = () => {
        setConnectionStatus('disconnected');
        es.close();
        setTimeout(connect, 5000); // reconnect after 5s
      };

      es.onmessage = (e) => {
        try {
          const reading = JSON.parse(e.data);
          setLatest(reading);
          markOnline(reading.timestamp);
          triggerFlash();

          setHistory(prev => {
            const next = [...prev, { ...reading, time: formatTime(reading.timestamp) }];
            return next.slice(-HISTORY_LIMIT);
          });

          // Update rolling stats
          setStats(prev => {
            if (!prev) return prev;
            const allTemps = [...(prev._temps ?? []), reading.temperature];
            const allHums = [...(prev._hums ?? []), reading.humidity];
            return {
              ...prev,
              _temps: allTemps,
              _hums: allHums,
              count: (prev.count ?? 0) + 1,
              temperature: {
                min: Math.min(prev.temperature.min, reading.temperature).toFixed(1),
                max: Math.max(prev.temperature.max, reading.temperature).toFixed(1),
                avg: (allTemps.reduce((a, b) => a + b, 0) / allTemps.length).toFixed(1),
              },
              humidity: {
                min: Math.min(prev.humidity.min, reading.humidity).toFixed(1),
                max: Math.max(prev.humidity.max, reading.humidity).toFixed(1),
                avg: (allHums.reduce((a, b) => a + b, 0) / allHums.length).toFixed(1),
              },
              last_updated: reading.timestamp,
            };
          });
        } catch (err) {
          console.error('SSE parse error:', err);
        }
      };
    };

    connect();
    return () => {
      eventSourceRef.current?.close();
      clearTimeout(offlineTimerRef.current);
    };
  }, [fetchInitialData, markOnline, triggerFlash]);

  // Polling fallback: every 5s fetch latest from DB and apply if it's newer than what SSE delivered
  useEffect(() => {
    const poll = setInterval(async () => {
      try {
        const res = await fetch('/api/sensor/latest');
        const row = await res.json();
        if (!row) return;
        if (!latestTimestampRef.current || row.timestamp > latestTimestampRef.current) {
          markOnline(row.timestamp);
          triggerFlash();
          setLatest(row);
          setHistory(prev => {
            const next = [...prev, { ...row, time: formatTime(row.timestamp) }];
            return next.slice(-HISTORY_LIMIT);
          });
        }
      } catch (e) {
        console.error('[Poll] fetch error:', e);
      }
    }, 5000);
    return () => clearInterval(poll);
  }, [markOnline, triggerFlash]);

  // ── Comfort level label based on temp + humidity ──
  const comfortLevel = () => {
    if (!latest) return null;
    const { temperature: t, humidity: h } = latest;
    if (t > 35) return { label: 'Very Hot', color: '#ef4444' };
    if (t > 30) return { label: 'Hot', color: '#f97316' };
    if (t > 25) return { label: 'Warm', color: '#eab308' };
    if (t > 20 && h < 60) return { label: 'Comfortable', color: '#10b981' };
    if (t > 15) return { label: 'Cool', color: '#06b6d4' };
    return { label: 'Cold', color: '#3b82f6' };
  };

  const comfort = comfortLevel();

  const clearData = async () => {
    if (!confirm('Clear all sensor readings?')) return;
    await fetch('/api/sensor/data', { method: 'DELETE' });
    setLatest(null);
    setHistory([]);
    setStats(null);
  };

  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(135deg, #0a0f1e 0%, #0d1526 50%, #0a0f1e 100%)' }}>
      {/* ── Header ── */}
      <header className="border-b border-slate-800 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #3b82f6, #06b6d4)' }}>
              <Thermometer size={18} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-100 leading-none">IoT Sensor Dashboard</h1>
              <p className="text-xs text-slate-500 mt-0.5">ESP32 + DHT11 • Real-time monitoring</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Live status badge */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium"
              style={{
                background: online ? '#052e16' : '#1c0a09',
                border: `1px solid ${online ? '#16a34a' : '#9a3412'}`,
                color: online ? '#4ade80' : '#f87171',
              }}>
              <span className={`w-2 h-2 rounded-full ${online ? 'bg-green-400' : 'bg-red-400'} ${online ? 'animate-pulse' : ''}`} />
              {connectionStatus === 'live' ? 'LIVE' : connectionStatus === 'connecting' ? 'Connecting...' : 'Offline'}
            </div>

            <button onClick={fetchInitialData}
              className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
              title="Refresh">
              <RefreshCw size={16} />
            </button>
            <button onClick={clearData}
              className="p-2 rounded-lg hover:bg-red-900/30 text-slate-500 hover:text-red-400 transition-colors"
              title="Clear data">
              <Trash2 size={16} />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-6 space-y-6">

        {/* ── Device info bar ── */}
        <div className="flex items-center gap-6 text-xs text-slate-500">
          <span className="flex items-center gap-1.5">
            <Activity size={12} className="text-blue-400" />
            Device: <span className="text-slate-300 ml-1">{latest?.device_id ?? '--'}</span>
          </span>
          <span className="flex items-center gap-1.5">
            <Clock size={12} className="text-blue-400" />
            Last update: <span className="text-slate-300 ml-1">{lastSeen ? timeAgo(lastSeen) : '--'}</span>
          </span>
          {lastSeen && (
            <span className="text-slate-600">{formatFullTime(lastSeen)}</span>
          )}
          {comfort && (
            <span className="ml-auto flex items-center gap-1.5">
              <Wind size={12} style={{ color: comfort.color }} />
              <span style={{ color: comfort.color }} className="font-semibold">{comfort.label}</span>
            </span>
          )}
        </div>

        {/* ── Gauges + current readings ── */}
        <div className={`grid grid-cols-1 lg:grid-cols-2 gap-6 transition-all duration-300 ${flashUpdate ? 'scale-[1.002]' : 'scale-100'}`}>

          {/* Temperature card */}
          <div className="rounded-2xl p-6 border border-slate-700/50 relative overflow-hidden"
            style={{ background: 'linear-gradient(135deg, #111827 0%, #1a1f30 100%)' }}>
            <div className="absolute top-0 right-0 w-32 h-32 rounded-full opacity-5"
              style={{ background: '#f97316', filter: 'blur(40px)', transform: 'translate(20%, -20%)' }} />

            <div className="flex items-start justify-between mb-4">
              <div>
                <h2 className="text-sm font-medium text-slate-400 uppercase tracking-wider">Temperature</h2>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-5xl font-bold" style={{ color: '#f97316' }}>
                    {latest?.temperature?.toFixed(1) ?? '--'}
                  </span>
                  <span className="text-xl text-slate-400">°C</span>
                </div>
                <p className="text-sm text-slate-500 mt-1">
                  {latest?.temperature !== undefined
                    ? `${(latest.temperature * 9 / 5 + 32).toFixed(1)}°F`
                    : 'Waiting for sensor...'}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: '#f9731615', border: '1px solid #f9731630' }}>
                <Thermometer size={22} style={{ color: '#f97316' }} />
              </div>
            </div>

            <Gauge
              value={latest?.temperature ?? null}
              min={0} max={50}
              unit="°C"
              color="#f97316"
              label="Temperature"
              icon={Thermometer}
              subtitle="Range: 0–50°C"
            />

            {/* Temp stats row */}
            {stats && (
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[
                  { label: 'Min', value: stats.temperature.min },
                  { label: 'Avg', value: stats.temperature.avg },
                  { label: 'Max', value: stats.temperature.max },
                ].map(({ label, value }) => (
                  <div key={label} className="text-center py-2 rounded-lg" style={{ background: '#f9731610' }}>
                    <p className="text-[10px] text-slate-500 uppercase">{label}</p>
                    <p className="text-sm font-semibold" style={{ color: '#fb923c' }}>{value}°C</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Humidity card */}
          <div className="rounded-2xl p-6 border border-slate-700/50 relative overflow-hidden"
            style={{ background: 'linear-gradient(135deg, #111827 0%, #1a1f30 100%)' }}>
            <div className="absolute top-0 right-0 w-32 h-32 rounded-full opacity-5"
              style={{ background: '#06b6d4', filter: 'blur(40px)', transform: 'translate(20%, -20%)' }} />

            <div className="flex items-start justify-between mb-4">
              <div>
                <h2 className="text-sm font-medium text-slate-400 uppercase tracking-wider">Humidity</h2>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-5xl font-bold" style={{ color: '#06b6d4' }}>
                    {latest?.humidity?.toFixed(1) ?? '--'}
                  </span>
                  <span className="text-xl text-slate-400">%</span>
                </div>
                <p className="text-sm text-slate-500 mt-1">
                  {latest?.humidity !== undefined
                    ? latest.humidity < 30 ? 'Dry — consider a humidifier'
                      : latest.humidity > 60 ? 'Humid — good ventilation advised'
                        : 'Comfortable range'
                    : 'Waiting for sensor...'}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: '#06b6d415', border: '1px solid #06b6d430' }}>
                <Droplets size={22} style={{ color: '#06b6d4' }} />
              </div>
            </div>

            <Gauge
              value={latest?.humidity ?? null}
              min={0} max={100}
              unit="%"
              color="#06b6d4"
              label="Humidity"
              icon={Droplets}
              subtitle="Range: 0–100%"
            />

            {stats && (
              <div className="grid grid-cols-3 gap-3 mt-4">
                {[
                  { label: 'Min', value: stats.humidity.min },
                  { label: 'Avg', value: stats.humidity.avg },
                  { label: 'Max', value: stats.humidity.max },
                ].map(({ label, value }) => (
                  <div key={label} className="text-center py-2 rounded-lg" style={{ background: '#06b6d410' }}>
                    <p className="text-[10px] text-slate-500 uppercase">{label}</p>
                    <p className="text-sm font-semibold" style={{ color: '#22d3ee' }}>{value}%</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ── Heat index card (if available) ── */}
        {latest?.heat_index !== null && latest?.heat_index !== undefined && (
          <div className="rounded-2xl p-5 border border-slate-700/50 flex items-center gap-6"
            style={{ background: 'linear-gradient(135deg, #111827 0%, #1a1f30 100%)' }}>
            <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: '#a855f715', border: '1px solid #a855f730' }}>
              <Wind size={20} style={{ color: '#a855f7' }} />
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wider">Heat Index (Feels Like)</p>
              <p className="text-2xl font-bold mt-0.5" style={{ color: '#c084fc' }}>
                {latest.heat_index.toFixed(1)}°C
              </p>
            </div>
          </div>
        )}

        {/* ── History chart ── */}
        {history.length > 1 && (
          <div className="rounded-2xl p-6 border border-slate-700/50"
            style={{ background: 'linear-gradient(135deg, #111827 0%, #1a1f30 100%)' }}>
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <BarChart2 size={16} className="text-blue-400" />
                <h2 className="text-sm font-semibold text-slate-200">Historical Readings</h2>
              </div>
              <span className="text-xs text-slate-500">{history.length} readings • last {HISTORY_LIMIT}</span>
            </div>

            {/* Temperature chart */}
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Thermometer size={11} style={{ color: '#f97316' }} /> Temperature (°C)
            </p>
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart data={history} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f97316" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f97316" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" tick={{ fill: '#475569', fontSize: 10 }} interval="preserveStartEnd" />
                <YAxis tick={{ fill: '#475569', fontSize: 10 }} domain={['auto', 'auto']} />
                <Tooltip content={<ChartTooltip />} />
                <Area type="monotone" dataKey="temperature" name="Temp" stroke="#f97316"
                  fill="url(#tempGradient)" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>

            {/* Humidity chart */}
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-2 mt-6 flex items-center gap-1.5">
              <Droplets size={11} style={{ color: '#06b6d4' }} /> Humidity (%)
            </p>
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart data={history} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="humGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" tick={{ fill: '#475569', fontSize: 10 }} interval="preserveStartEnd" />
                <YAxis tick={{ fill: '#475569', fontSize: 10 }} domain={[0, 100]} />
                <Tooltip content={<ChartTooltip />} />
                <ReferenceLine y={60} stroke="#f97316" strokeDasharray="4 4" label={{ value: '60% max', fill: '#f97316', fontSize: 9 }} />
                <ReferenceLine y={30} stroke="#3b82f6" strokeDasharray="4 4" label={{ value: '30% min', fill: '#3b82f6', fontSize: 9 }} />
                <Area type="monotone" dataKey="humidity" name="Humidity" stroke="#06b6d4"
                  fill="url(#humGradient)" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* ── No data state ── */}
        {!latest && (
          <div className="rounded-2xl p-12 border border-slate-700/50 text-center"
            style={{ background: 'linear-gradient(135deg, #111827 0%, #1a1f30 100%)' }}>
            <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: '#3b82f615', border: '1px solid #3b82f630' }}>
              <Wifi size={28} className="text-blue-400 animate-pulse" />
            </div>
            <h3 className="text-lg font-semibold text-slate-300 mb-2">Waiting for ESP32...</h3>
            <p className="text-sm text-slate-500 max-w-sm mx-auto">
              Make sure your ESP32 is powered on, connected to WiFi, and posting to{' '}
              <code className="text-blue-400 bg-slate-800 px-1.5 py-0.5 rounded text-xs">
                /api/sensor/data
              </code>
            </p>
            <div className="mt-6 inline-flex items-center gap-2 text-xs text-slate-600 bg-slate-800/50 rounded-lg px-4 py-2">
              <span className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />
              Listening on SSE stream...
            </div>
          </div>
        )}

        {/* ── Footer ── */}
        <footer className="text-center text-xs text-slate-700 pb-4">
          ESP32 + DHT11 Real-time Dashboard • Data refreshes automatically via Server-Sent Events
        </footer>
      </main>
    </div>
  );
}
