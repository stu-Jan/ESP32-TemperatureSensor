const Database = require('better-sqlite3');
const path     = require('path');

const db = new Database(path.join(__dirname, 'data', 'iot.db'));

db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS sensor_readings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    temperature REAL NOT NULL,
    humidity    REAL NOT NULL,
    heat_index  REAL DEFAULT NULL,
    device_id   TEXT NOT NULL DEFAULT 'esp32-01',
    timestamp   TEXT NOT NULL
  )
`);

db.exec(`CREATE INDEX IF NOT EXISTS idx_timestamp  ON sensor_readings(timestamp)`);
db.exec(`CREATE INDEX IF NOT EXISTS idx_device_id  ON sensor_readings(device_id)`);

console.log('[DB] SQLite ready →', path.join(__dirname, 'data', 'iot.db'));

module.exports = db;
