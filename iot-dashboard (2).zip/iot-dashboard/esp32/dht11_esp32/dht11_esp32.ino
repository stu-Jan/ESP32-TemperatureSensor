#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <ArduinoJson.h>

const char* WIFI_SSID     = "Precision Biometric";
const char* WIFI_PASSWORD = "b10metr1(321";

const char* MQTT_BROKER = "broker.hivemq.com";
const int   MQTT_PORT   = 1883;
const char* MQTT_TOPIC  = "iot/sensor/data";

const char* DEVICE_ID = "esp32-01";

#define DHTPIN  4
#define DHTTYPE DHT11
#define POST_INTERVAL_MS 5000

DHT dht(DHTPIN, DHTTYPE);
WiFiClient   wifiClient;
PubSubClient mqttClient(wifiClient);

unsigned long lastPostTime = 0;

void connectWiFi() {
  Serial.println("\nConnecting to WiFi: " + String(WIFI_SSID));
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 40) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected!");
    Serial.println("IP address: " + WiFi.localIP().toString());
    Serial.println("Signal strength (RSSI): " + String(WiFi.RSSI()) + " dBm");
  } else {
    Serial.println("\nWiFi connection FAILED. Will retry...");
  }
}

void connectMQTT() {
  while (!mqttClient.connected()) {
    Serial.print("[MQTT] Connecting...");
    String clientId = "esp32-" + String(random(0xffff), HEX);
    if (mqttClient.connect(clientId.c_str())) {
      Serial.println(" connected!");
    } else {
      Serial.printf(" failed (rc=%d), retrying in 5s\n", mqttClient.state());
      delay(5000);
    }
  }
}

float computeHeatIndex(float tempC, float humidity) {
  float tempF = tempC * 9.0 / 5.0 + 32.0;
  float hi = -42.379 + 2.04901523 * tempF + 10.14333127 * humidity
    - 0.22475541 * tempF * humidity - 0.00683783 * tempF * tempF
    - 0.05481717 * humidity * humidity + 0.00122874 * tempF * tempF * humidity
    + 0.00085282 * tempF * humidity * humidity
    - 0.00000199 * tempF * tempF * humidity * humidity;
  return (hi - 32.0) * 5.0 / 9.0;
}

void publishSensorData(float temperature, float humidity) {
  if (!mqttClient.connected()) connectMQTT();

  float heatIndex = computeHeatIndex(temperature, humidity);

  StaticJsonDocument<256> doc;
  doc["temperature"] = round(temperature * 10.0) / 10.0;
  doc["humidity"]    = round(humidity * 10.0) / 10.0;
  doc["heat_index"]  = round(heatIndex * 10.0) / 10.0;
  doc["device_id"]   = DEVICE_ID;

  char payload[256];
  serializeJson(doc, payload);

  Serial.print("[MQTT] Publish → ");
  Serial.println(payload);

  mqttClient.publish(MQTT_TOPIC, payload);
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("\n========================================");
  Serial.println("  ESP32 DHT11 IoT Sensor Starting...");
  Serial.println("========================================");

  dht.begin();
  connectWiFi();

  mqttClient.setServer(MQTT_BROKER, MQTT_PORT);
  connectMQTT();

  Serial.println("\nDHT11 sensor ready. Starting readings...\n");
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[WiFi] Connection lost, reconnecting...");
    connectWiFi();
    return;
  }

  if (!mqttClient.connected()) connectMQTT();
  mqttClient.loop();

  unsigned long now = millis();
  if (now - lastPostTime < POST_INTERVAL_MS) return;
  lastPostTime = now;

  float humidity    = dht.readHumidity();
  float temperature = dht.readTemperature();

  if (isnan(humidity) || isnan(temperature)) {
    Serial.println("[DHT11] Sensor read failed! Check wiring.");
    return;
  }

  Serial.printf("\n[%lu ms] Temp: %.1f°C (%.1f°F) | Humidity: %.1f%%\n",
    now, temperature, temperature * 9.0 / 5.0 + 32.0, humidity);

  publishSensorData(temperature, humidity);
}
