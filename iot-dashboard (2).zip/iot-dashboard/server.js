require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const path    = require('path');
const mqtt    = require('mqtt');
const db      = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

// SSE clients waiting for real-time updates
const sseClients = new Set();

// ── Shared: insert to DB + broadcast to SSE clients ───────────────────────────
function processReading(data) {
  const { temperature, humidity, device_id = 'esp32-01', heat_index } = data;

  const temp = parseFloat(temperature);
  const hum  = parseFloat(humidity);

  if (isNaN(temp) || isNaN(hum)) return null;

  const reading = {
    temperature: temp,
    humidity:    hum,
    heat_index:  heat_index !== undefined ? parseFloat(heat_index) : null,
    device_id,
    timestamp:   new Date().toISOString(),
  };

  db.prepare(
    'INSERT INTO sensor_readings (temperature, humidity, heat_index, device_id, timestamp) VALUES (?, ?, ?, ?, ?)'
  ).run(reading.temperature, reading.humidity, reading.heat_index, reading.device_id, reading.timestamp);

  const payload = `data: ${JSON.stringify(reading)}\n\n`;
  sseClients.forEach(client => {
    try { client.write(payload); } catch (e) { sseClients.delete(client); }
  });

  return reading;
}

// ── MQTT subscriber ───────────────────────────────────────────────────────────
const MQTT_BROKER = process.env.MQTT_BROKER || 'mqtt://broker.hivemq.com';
const MQTT_TOPIC  = process.env.MQTT_TOPIC  || 'iot/sensor/data';

const mqttClient = mqtt.connect(MQTT_BROKER, { reconnectPeriod: 5000 });

mqttClient.on('connect', () => {
  console.log(`[MQTT] Connected to ${MQTT_BROKER}`);
  mqttClient.subscribe(MQTT_TOPIC, err => {
    if (err) console.error('[MQTT] Subscribe error:', err.message);
    else     console.log(`[MQTT] Subscribed → ${MQTT_TOPIC}`);
  });
});

mqttClient.on('message', (topic, message) => {
  try {
    const data    = JSON.parse(message.toString());
    const reading = processReading(data);
    if (reading) {
      console.log(`[MQTT][${reading.timestamp}] ${reading.device_id} — Temp: ${reading.temperature}°C | Humidity: ${reading.humidity}%`);
    } else {
      console.warn('[MQTT] Invalid reading — temperature/humidity missing or not a number');
    }
  } catch (e) {
    console.error('[MQTT] Invalid JSON:', e.message);
  }
});

mqttClient.on('error',     err => console.error('[MQTT] Error:', err.message));
mqttClient.on('reconnect', ()  => console.log('[MQTT] Reconnecting...'));

// ── HTTP fallback: ESP32 can still POST here ──────────────────────────────────
app.post('/api/sensor/data', (req, res) => {
  const { temperature, humidity } = req.body;

  if (temperature === undefined || humidity === undefined) {
    return res.status(400).json({ error: 'temperature and humidity are required' });
  }

  const reading = processReading(req.body);
  if (!reading) return res.status(400).json({ error: 'temperature and humidity must be numbers' });

  console.log(`[HTTP][${reading.timestamp}] ${reading.device_id} — Temp: ${reading.temperature}°C | Humidity: ${reading.humidity}%`);
  res.json({ success: true, reading });
});

// ── Get latest reading ────────────────────────────────────────────────────────
app.get('/api/sensor/latest', (req, res) => {
  const row = db.prepare('SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT 1').get();
  res.json(row ?? null);
});

// ── Get reading history ───────────────────────────────────────────────────────
app.get('/api/sensor/history', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 50, 500);
  const rows = db.prepare(
    'SELECT * FROM (SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT ?) ORDER BY timestamp ASC'
  ).all(limit);
  res.json(rows);
});

// ── Server-Sent Events ────────────────────────────────────────────────────────
app.get('/api/sensor/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  const latest = db.prepare('SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT 1').get();
  if (latest) res.write(`data: ${JSON.stringify(latest)}\n\n`);

  sseClients.add(res);
  console.log(`[SSE] Client connected (total: ${sseClients.size})`);
  req.on('close', () => {
    sseClients.delete(res);
    console.log(`[SSE] Client disconnected (total: ${sseClients.size})`);
  });
});

// Heartbeat: keep all SSE connections alive every 20 seconds
setInterval(() => {
  const dead = [];
  sseClients.forEach(client => {
    try {
      client.write(':keepalive\n\n');
    } catch (e) {
      dead.push(client);
    }
  });
  dead.forEach(c => sseClients.delete(c));
}, 20_000);

// ── Stats summary ─────────────────────────────────────────────────────────────
app.get('/api/sensor/stats', (req, res) => {
  const r = db.prepare(`
    SELECT
      COUNT(*)         AS count,
      MIN(temperature) AS temp_min,
      MAX(temperature) AS temp_max,
      AVG(temperature) AS temp_avg,
      MIN(humidity)    AS hum_min,
      MAX(humidity)    AS hum_max,
      AVG(humidity)    AS hum_avg,
      MAX(timestamp)   AS last_updated
    FROM sensor_readings
  `).get();

  if (!r || r.count === 0) return res.json(null);

  res.json({
    count: r.count,
    temperature: {
      min: parseFloat(r.temp_min).toFixed(1),
      max: parseFloat(r.temp_max).toFixed(1),
      avg: parseFloat(r.temp_avg).toFixed(1),
    },
    humidity: {
      min: parseFloat(r.hum_min).toFixed(1),
      max: parseFloat(r.hum_max).toFixed(1),
      avg: parseFloat(r.hum_avg).toFixed(1),
    },
    last_updated: r.last_updated,
  });
});

// ── Clear all data ────────────────────────────────────────────────────────────
app.delete('/api/sensor/data', (req, res) => {
  db.prepare('DELETE FROM sensor_readings').run();
  res.json({ success: true });
});

// ── Serve built React app ─────────────────────────────────────────────────────
const distPath = path.join(__dirname, 'react-app', 'dist');
app.use(express.static(distPath));
app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n IoT Dashboard Server running on http://localhost:${PORT}`);
  console.log(` ESP32 should POST to: http://<your-ip>:${PORT}/api/sensor/data\n`);
});
