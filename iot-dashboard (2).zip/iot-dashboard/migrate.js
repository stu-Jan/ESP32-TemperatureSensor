const fs   = require('fs');
const path = require('path');
const db   = require('./db');

const dataFile = path.join(__dirname, 'data', 'readings.json');

if (!fs.existsSync(dataFile)) {
  console.log('No readings.json found — nothing to migrate.');
  process.exit(0);
}

const raw = fs.readFileSync(dataFile, 'utf8').trim();
if (!raw || raw === '[]') {
  console.log('readings.json is empty — nothing to migrate.');
  process.exit(0);
}

const readings = JSON.parse(raw);
console.log(`Found ${readings.length} readings. Migrating to SQLite...`);

const insert = db.prepare(
  'INSERT INTO sensor_readings (temperature, humidity, heat_index, device_id, timestamp) VALUES (?, ?, ?, ?, ?)'
);

const migrateAll = db.transaction((rows) => {
  for (const r of rows) {
    insert.run(
      parseFloat(r.temperature),
      parseFloat(r.humidity),
      r.heat_index != null ? parseFloat(r.heat_index) : null,
      r.device_id || 'esp32-01',
      r.timestamp
    );
  }
});

migrateAll(readings);
console.log(`Done! ${readings.length} readings inserted into SQLite.`);
